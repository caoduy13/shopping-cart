function appendResult(text) {
    const resultElement = document.getElementById('result');
    resultElement.innerText += text + '\n';
    resultElement.scrollTop = resultElement.scrollHeight;
}

function clearOutput() {
    document.getElementById('result').innerText = '';
}


function runQuestion1() {
    clearOutput();
    let arraySize;
    let numbers = [];
    const maxElements = 50;

    arraySize = parseInt(prompt(`Bai 1: Nhap so phan tu cua mang (khong qua ${maxElements}):`));
    
    while (isNaN(arraySize) || arraySize <= 0 || arraySize > maxElements) {
        arraySize = parseInt(prompt("Loi: So luong phan tu khong hop le. Vui long nhap lai:"));
    }

    for (let i = 0; i < arraySize; i++) {
        let input = parseInt(prompt(`Nhap phan tu thu ${i + 1}:`));
        if (!isNaN(input)) {
            numbers.push(input);
        } else {
            appendResult("Dau vao khong hop le. Vui long nhap mot so.");
            i--;
        }
    }

    appendResult("Mang da nhap la: " + numbers.join(', '));

    let sum = 0;
    let count = 0;
    for (let number of numbers) {
        if (number % 3 === 0) {
            sum += number;
            count++;
        }
    }

    if (count > 0) {
        const average = sum / count;
        appendResult("Trung binh cong cac so chia het cho 3 la: " + average.toFixed(2));
    } else {
        appendResult("Khong co so nao chia het cho 3 trong mang.");
    }
}


function runQuestion2() {
    clearOutput();
    function isPerfectNumber(num) {
        if (num <= 1) {
            return false;
        }
        let sumOfDivisors = 1;
        for (let i = 2; i * i <= num; i++) {
            if (num % i === 0) {
                sumOfDivisors += i;
                if (i * i !== num) {
                    sumOfDivisors += num / i;
                }
            }
        }
        return sumOfDivisors === num;
    }

    let numberToCheck = parseInt(prompt("Bai 2: Nhap mot so nguyen duong de kiem tra so hoan hao:"));
    
    if (!isNaN(numberToCheck) && numberToCheck > 0) {
        const result = isPerfectNumber(numberToCheck) ? "la so hoan hao." : "khong phai la so hoan hao.";
        appendResult(`So ${numberToCheck} ${result}`);
    } else {
        appendResult("Dau vao khong hop le. Vui long nhap mot so nguyen duong.");
    }
}


function runQuestion3() {
    clearOutput();
    function isLeapYear(year) {
        return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    }

    function getDaysInMonth(month, year) {
        switch (month) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                return 31;
            case 4: case 6: case 9: case 11:
                return 30;
            case 2:
                return isLeapYear(year) ? 29 : 28;
            default:
                return -1;
        }
    }
    
    const input = prompt("Bai 3: Nhap thang va nam theo dinh dang MM/yyyy:");
    const parts = input.split('/');
    
    if (parts.length === 2) {
        const month = parseInt(parts[0]);
        const year = parseInt(parts[1]);

        if (!isNaN(month) && !isNaN(year) && month >= 1 && month <= 12) {
            const days = getDaysInMonth(month, year);
            if (days !== -1) {
                appendResult(`Thang ${month} nam ${year} co ${days} ngay.`);
            } else {
                appendResult("Thang hoac nam khong hop le.");
            }
        } else {
            appendResult("Dinh dang nhap khong hop le. Vui long nhap theo dinh dang MM/yyyy.");
        }
    } else {
        appendResult("Dinh dang nhap khong hop le. Vui long nhap theo dinh dang MM/yyyy.");
    }
}


function runQuestion4() {
    clearOutput();
    class Worker {
        constructor(stt, fullName, dob, address, salary, position) {
            this.stt = stt;
            this.fullName = fullName;
            this.dob = dob;
            this.address = address;
            this.salary = salary;
            this.position = position;
        }
    }

    const workers = [
        new Worker(1, "Truong Tan A", "11-11-1997", "Quang Nam", 2000, "Abc"),
        new Worker(2, "Truong Tan B", "11-11-1998", "Da Nang", 2000, "Abc"),
        new Worker(3, "Truong Tan C", "11-11-1999", "Hue", 2000, "Abc")
    ];

    function displayWorkers(workerList) {
        const header = "STT | Ho va ten          | Ngay sinh      | Dia chi      | Luong | Chuc vu";
        const separator = "---------------------------------------------------------------------------------";
        
        appendResult(separator);
        appendResult(header);
        appendResult(separator);
        
        workerList.forEach(worker => {
            const row = `${String(worker.stt).padEnd(3)} | ${worker.fullName.padEnd(18)} | ${worker.dob.padEnd(14)} | ${worker.address.padEnd(12)} | ${String(worker.salary).padEnd(5)} | ${worker.position}`;
            appendResult(row);
        });
        
        appendResult(separator);
    }

    appendResult("Danh sach cong nhan ban dau:");
    displayWorkers(workers);

    workers.sort((a, b) => a.fullName.localeCompare(b.fullName, 'vi', { sensitivity: 'base' }));

    appendResult("\nDanh sach cong nhan sau khi sap xep theo ho va ten:");
    displayWorkers(workers);
}


document.getElementById('btn-question1').addEventListener('click', runQuestion1);
document.getElementById('btn-question2').addEventListener('click', runQuestion2);
document.getElementById('btn-question3').addEventListener('click', runQuestion3);
document.getElementById('btn-question4').addEventListener('click', runQuestion4);
document.getElementById('btn-clear').addEventListener('click', clearOutput);
