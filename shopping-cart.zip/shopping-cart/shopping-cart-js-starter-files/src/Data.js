let shopItemsData = [
  {
    id: "jfhgbvnscs",
    name: "Motor Nuclear MNQ-01",
    price: 190,
    desc: "Motor Nuclear MNQ 01 (Bach Khởi) là mô hình kim loại 1/72 có thể lắp ghép thành rồng vàng, thuộc dòng sản phẩm Metal Build BaiQi với bộ xương kim loại và giáp nhựa ABS/PS, có đèn LED ở mắt, cánh hiệu ứng và vũ khí đi kèm. ",
    img: "images/img-1.webp",
  },
  {
    id: "ioytrhndcv",
    name: "Motor Nuclear MNQ-02",
    price: 160,
    desc: "Motor Nuclear MNQ-02, hay CaoRen, là một mô hình kit nhựa (plastic model kit) lắp ráp tỉ lệ 1/72, có chiều cao khoảng 26cm, bao gồm bộ khung kim loại (metal build) bên trong và giáp ABS/PS, có đèn LED ở mắt, hiệu ứng cánh và vũ khí đi kèm.",
    img: "images/img-2.webp",
  },
  {
    id: "wuefbncxbsn",
    name: "Motor Nuclear MNQ-03",
    price: 205,
    desc: "Motor Nuclear MNQ-03, hay Bộ Mô hình lắp ráp MNQ-03 Ao Bing và rồng xanh, là một sản phẩm kit nhựa và kim loại do hãng Motor Nuclear của Trung Quốc sản xuất. Sản phẩm này bao gồm một mô hình rồng xanh chưa lắp ráp và là hàng mới 100%, được mô tả là có chất lượng cao, sắc nét và dễ lắp ráp. ",
    img: "images/img-3.webp",
  },
  {
    id: "thyfhcbcv",
    name: "Motor Nuclear MNQ-04",
    price: 220,
    desc: "Motor Nuclear MNQP-XH04 (MNQ-04) là mô hình lắp ráp chiến thần Can Tương GanJiang, thuộc dòng Metal Build của Motor Nuclear, với khung xương kim loại, chi tiết nhựa ABS, POM và kích thước khoảng 16cm.",
    img: "images/img-4.webp",
  },
];
